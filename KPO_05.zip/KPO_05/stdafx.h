#ifndef STDAFX_H
#define STDAFX_H

#include "Dictionary.h"
#include <iostream>
#include <windows.h>
#include <string>
#include <cstring>

#define TEST_CREATE_01 

#define TEST_CREATE_02 

#define TEST_ADDENTRY_03 

#define TEST_ADDENTRY_04 

#define TEST_GETENTRY_05 

#define TEST_DEL_ENTRY_06 
        
#define TEST_UPD_ENTRY_07 

#define TEST_UPD_ENTRY_08 

#define TEST_DICTIONARY

#endif 